# Traductor C

Usar "make test" para las pruebas.
