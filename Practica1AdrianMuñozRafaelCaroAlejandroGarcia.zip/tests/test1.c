a = 4 * y + z;b = x / z - 3;c = a + b - x * y / z;
